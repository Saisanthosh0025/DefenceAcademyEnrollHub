
<footer class="main-footer">
            <strong>Copyright &copy; 2023 <a href="https://www.linkedin.com/in/pichika-hem-chandra-sai-santhosh-1023b3246" target=" ">P. H. C. SAI SANTOSH</a>.</strong> All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 
            </div>
        </footer>
		
		